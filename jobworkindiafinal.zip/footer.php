 <!-- Footer Section -->
    <footer>
      <!-- Container Starts -->
      <div class="container">
        <!-- Row Starts -->
        <div class="row">
          <!-- Footer Widget Starts -->
          <div class="footer-widget col-md-3 col-xs-12 wow fadeIn">
            <h3 class="small-title">
              Know Us.
            </h3>
            <p>
                <img src="assets/images/log.png" alt="" class="img-responsive">
            </p>
            <p>
              JobWork India is Ahmeadabad's Leading Jobwork Servicer provider. 
            </p>  

               
          </div><!-- Footer Widget Ends -->
          
          <!-- Footer Widget Starts -->
          <div class="footer-widget col-md-3 col-xs-12 wow fadeIn" data-wow-delay=".2s">
            <h3 class="small-title">
              About Us
            </h3>
            <ul class="recent-tweets">
                <p>JobWork India is is the Ahmedabad's Largest online marketplace for referencing service seeker to service provider. We are leading reference provider company from Ahmedabad. We provide B2B links so that organization can grow up business in an effective way. </p>
              
              
            </ul>
          </div><!-- Footer Widget Ends -->

          <!-- Footer Widget Starts -->
          <div class="footer-widget col-md-3 col-xs-12 wow fadeIn" data-wow-delay=".5s" style="padding-left: 40px;">
            <h3 class="small-title">
              Pages
            </h3>
            <div class="plain-flicker-gallery">
                <ul>
                    <li>Private Policy</li>
                    <li>Documentation</li>
                    <li>Terms & Conditions</li>
                    <li>Rights</li>
                </ul>
            </div>
          </div><!-- Footer Widget Ends -->

          <!-- Footer Widget Starts -->
          <div class="footer-widget col-md-3 col-xs-12 wow fadeIn" data-wow-delay=".8s">
            <h3 class="small-title">
              Find Us
            </h3>
             <div class="social-links-bordered">
              <a href="#" class="social-link" data-toggle="tooltip" data-placement="bottom" title="Twitter">
                <i class="fa fa-twitter">
                </i>
              </a>
              <a href="#" class="social-link" data-toggle="tooltip" data-placement="bottom" title="Facebook">
                <i class="fa fa-facebook">
                </i>
              </a>
              <a href="#" class="social-link" data-toggle="tooltip" data-placement="bottom" title="Google+">
                <i class="fa fa-google-plus">
                </i>
              </a>
              <a href="#" class="social-link" data-toggle="tooltip" data-placement="bottom" title="LinkedIn">
                <i class="fa fa-linkedin">
                </i>
              </a>
            </div>      
          </div><!-- Footer Widget Ends -->
        </div><!-- Row Ends -->
      </div><!-- Container Ends -->
      
      <!-- Copyright -->
      <div id="copyright">
        <div class="container">
          <div class="row">
            <div class="col-md-9 col-sm-6">
              <p class="copyright-text">
                ©  2017 Jobwork India. All right reserved. 
              </p>
            </div>
            <div class="col-md-3  col-sm-6">
              <p class="copyright-text pull-right"></a></p>             
            </div>
          </div>
        </div>
      </div>
      <!-- Copyright  End-->
      
    </footer>
    <!-- Footer Section End-->